package com.example.android.quizz;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    int score = 0;
    int fault = 0;
    boolean nile = false;
    boolean egyptriver = false;
    boolean nebal = false;
    boolean africa = false;
    boolean middleeast = false;
    boolean eroube = false;
    boolean learning = false;
    boolean enjoying = false;
    boolean playingfootball= false;
    boolean yes1 = false;
    boolean no1 = false;
    boolean yes2 = false;
    boolean no2 = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


    public void nile (View view){

          nile=!nile;

        if(nile==true){

            score+=1;
        }
              else {

            fault+=1;
        }




            }


    public void Egyptriver (View view){

        egyptriver=!egyptriver;

        if (egyptriver==true) {


            score+=1;
        }
    else {
            fault+=1;

        }
    }


    public void nebal (View view){

        nebal=!nebal;

        if (nebal==false) {


            score += 1;


        }
        else {
            fault+=1;

        }
    }

    public void africa (View view){

        africa=! africa;

        if (africa==false) {


            score+=1;


        }
        else {
            fault+=1;

        }


    }


    public void middleeast (View view){

       middleeast=!middleeast;

        if (middleeast==false) {

            score+=1;
        }

        else {
            fault+=1;
        }
    }


    public void eroube (View view){

       eroube=!eroube;

        if (eroube==true) {


            score+=1;


        }
        else {
            fault+=1;

        }
    }


    public void learning (View view){

        learning=!learning;

        if (learning==false) {

            score+=1;
        }

        else {
            fault+=1;
        }
    }

    public void enjoying (View view){

        enjoying=!enjoying;

        if (enjoying==false) {

            score+=1;
        }

        else {
            fault+=1;
        }
    }

    public void playingfootball (View view){

        playingfootball=!playingfootball;

        if (playingfootball==true) {

            score+=1;
        }

        else {
            fault+=1;
        }
    }

    public void like (View view){

        yes1=!yes1;

        if (yes1==true) {

            score+=1;
        }

        else {
            fault+=1;
        }
    }

    public void interested (View view){

       yes2=!yes2;

        if (yes2==true) {

            score+=1;
        }

        else {
            fault+=1;
        }
    }


    public void display(String message) {

        TextView ScoreView = (TextView) findViewById(R.id.socre_view);
        ScoreView.setText(message);
        ScoreView.setHighlightColor(Color.YELLOW);
    }
        public void submit (View view){
// onCheckboxClicked(view);
        display("the score is"+ score +"\n the fualts is "+fault);



    }

    public void reset (View view){


        score= 0 ;
        fault = 0;

        display("the score is"+ score +"\n the fualts is "+fault );

    }
}












